// DM2008 — Activity 1b [Georg Nees]
// Learning By Making (30 min)

function setup() {
  createCanvas(800, 800);
  background(200);
}

function draw() {
  let x = random(800);
    let y = random(800);
    let w = random(10,50);
DrawSmile(x, y, w);
}

function DrawSmile(x, y, w) {
  fill("#fff152");
  stroke(0);
  strokeWeight(w/20);
  circle(x, y, w);

let smile = random(1);

  if (smile < 0.5) {
    noFill();
      stroke(0);
  strokeWeight(w/20);
  arc(x, y, w/2, w/2, 0, PI);
  }
  else {
  fill("#ff0000");
    stroke(0);
  strokeWeight(w/20);
  arc(x, y, w/2, w/2, 0, PI, CHORD);
  }

  fill("#000000");
  noStroke();
  circle(x - w/4, y - w/6, w/10);
  circle(x + w/4, y - w/6, w/10);


}

function keyPressed() {
    saveCanvas("activity1b-image", "jpg");
}