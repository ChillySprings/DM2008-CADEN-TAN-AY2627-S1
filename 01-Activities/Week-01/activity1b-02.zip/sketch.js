// DM2008 — Activity 1b [Georg Nees]
// Learning By Making (30 min)

  let y = -1000;

function setup() {
  createCanvas(800, 800)
  frameRate(3)
}

function draw() {
background(50)

  noStroke();
  for (i = 0; i < random(50, 200); i++) {
    circle(random(width), y + random(1000), random(5, 10));
  }
y += 10

  if (y > 0) {
    y = -500
  }
}

function keyPressed() {
    saveCanvas("activity1b-image", "jpg");
}