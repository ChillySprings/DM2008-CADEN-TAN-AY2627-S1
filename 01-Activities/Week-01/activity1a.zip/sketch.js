function setup() {
  // function setup() runs only once at the start.
  createCanvas(400, 400);

  background(200);

  let colour = color(255, 204, 0);
  strokeWeight(3);
  fill(colour);
  circle(200, 200, 400);

  fill(color);
  circle(100, 150, 50);

  fill(color);
  circle(300, 150, 50);

  noFill();
  strokeWeight(3);
  arc(250, 200, 100, 50, 0, PI);

  noFill();
  strokeWeight(3);
  arc(150, 200, 100, 50, 0, PI);

  console.log("Ligma");
  // This prints through the console
}

function draw() {
  // function draw() runs repeatedly in a loop

  createCanvas(400, 400);

  background(200);

  let colour = color(255 * sin(frameCount * 0.05), 255 * sin(1 + frameCount * 0.05), 255 * sin(2 + frameCount * 0.05));
  strokeWeight(3);
  fill(colour);
  circle(200, 200, 400);

  fill(0);
  circle(100, 150, 50);

  fill(0);
  circle(300, 150, 50);

  noFill();
  strokeWeight(3);
  arc(250, 200, 100, 50, 0, PI);

  noFill();
  strokeWeight(3);
  arc(150, 200, 100, 50, 0, PI);
  
  arc(200, 225, 100, 150, 0, PI);
}
