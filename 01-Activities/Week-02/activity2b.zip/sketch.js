let rectW = 10;
let rectH = 40;
let y = 0;
let amplitude = 100;
let waveSpeed = 0.1;
let waveDelay = 0.5;
let colourSpeed = 0.1;
let squareWH = 40;

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(255);
  DrawPattern();
}

function DrawPattern() {
  let ySpacing = 0;

  for (let i = 0; i < 10; i++) {
      let xSpacing = 0;
    let x = -225 + amplitude * sin(frameCount * waveSpeed - i * waveDelay);

      let c = color(127.5 + 127.5 * sin(frameCount * colourSpeed - i * waveDelay), 127.5 + 127.5 * sin(1 + frameCount * colourSpeed - i * waveDelay), 127.5 + 127.5 * sin(1 - frameCount * colourSpeed - i * waveDelay));

    
    for (let i = 0; i < 30; i++) {
      fill(c);
      if (i % 5 == 0) {
        square(x + xSpacing, y + ySpacing, squareWH);
        xSpacing += squareWH * 2;
      } else {
        rect(x + xSpacing, y + ySpacing, rectW, rectH);
        xSpacing += rectW * 2;
      }
    }
    ySpacing += rectH;
  }
}

function mousePressed() {
  waveSpeed = 0;
}

function mouseReleased() {
  waveSpeed = 0.1;
}

function keyPressed() {
    saveCanvas("activity2b-image", "jpg");
}
