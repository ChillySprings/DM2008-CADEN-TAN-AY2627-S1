let velocityY = 0;
let gravityForce = 0.5;
let terminalGravity = 10;
let jumpForce = -10;
let canJump = true;
let isSmile = false;
let smileDelay = 0;
let smileCooldown = 20;
let x = 100;
let y = 200;
let w = 50;

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  drawSmile();
  smile();
  gravity();
  jump();
  if (velocityY >= 0) {
    canJump = true;
  }
  print(velocityY);
}

function drawSmile() {
  fill("#fff152");
  stroke(0);
  strokeWeight(w / 30);
  circle(x, y, w);

  if (isSmile) {
    arc(x, y, w / 2, w / 2, 0, PI);
  } else {
    fill("#ff0000");
    stroke(0);
    strokeWeight(w / 20);
    arc(x, y, w / 2, w / 2, 0, PI, CHORD);
  }

  fill("#000000");
  noStroke();
  circle(x - w / 4, y - w / 6, w / 10);
  circle(x + w / 4, y - w / 6, w / 10);
}

function gravity() {
  if (velocityY < terminalGravity) {
    velocityY += gravityForce;
  }
  y += velocityY;
}

function jump() {
  if (canJump && keyIsPressed && key == " ") {
    velocityY = jumpForce;
    canJump = false;
  }
}

function smile() {
  if (smileDelay > 0) {
    smileDelay -= 1;
  }
  if (mouseIsPressed && smileDelay <= 0) {
    isSmile = !isSmile;
    smileDelay = smileCooldown;
  }
}

function keyPressed() {
  if (key == "y") {
    saveCanvas("activity1a-image", "jpg");
  }
}
