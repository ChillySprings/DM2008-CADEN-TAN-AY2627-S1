let drawCircle = false;
let x = [];
let y = [];
let w = [];
let wMin = 50;
let wMax = 100;
let speed = 0.05;

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(255, 20);
  generateValues();

  noFill();
  if (drawCircle) {
    drawCircles()
  }
  else {
    drawSquares()
  }
}

function generateValues() {
  if (frameCount % 30 == 0) {
    x.push(random(width));
    y.push(random(height));
    w.push(random(wMin, wMax));
  }
}

function drawCircles() {
  for (let i = 0; i < x.length; i++) {
    circle(x[i], y[i], w[i]);
  }
}

function drawSquares() {
    for (let i = 0; i < x.length; i++) {
      push();
      translate(x[i], y[i]);
      rectMode(CENTER);
      rotate(frameCount * speed);
    square(0, 0, w[i]);
      pop();
    }
}

function keyPressed() {
      drawCircle = !drawCircle;
}