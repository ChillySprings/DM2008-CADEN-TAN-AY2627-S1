let deck = [
  2,
  2,
  2,
  2,
  3,
  3,
  3,
  3,
  4,
  4,
  4,
  4,
  5,
  5,
  5,
  5,
  6,
  6,
  6,
  6,
  7,
  7,
  7,
  7,
  8,
  8,
  8,
  8,
  9,
  9,
  9,
  9,
  10,
  10,
  10,
  10,
  10,
  10,
  10,
  10,
  10,
  10,
  10,
  10,
  11,
  11,
  11,
  11,
];
let playerHand = [];
let playerAceIndex = [];
let playerFlip = true;

let opponentHand = [];
let opponentAceIndex = [];
let opponentTurn = false;
let opponentRiskTolerance = 17;
let riskMultiplier = 0;
let checkMultiplier = false;
let opponentFlip = false;

let stateText = "";
let textS = 20;

function setup() {
  createCanvas(500, 500);

  startingHands();
}

function draw() {
  background(220);

  push();
    textSize(10);
  text("Press 1 to draw a card.", 10, 470);
  text("Press 2 to pass your turn.", 10, 480);
  text("Refresh the page to restart the game.", 10, 490);
  pop();
  
  if (opponentTurn) {
    opponentsTurn();
  }
  drawHand(playerHand, playerAceIndex, playerFlip);
  drawHand(opponentHand, opponentAceIndex, opponentFlip);
  textState();
}

function startingHands() {
  for (let i = 0; i < 4; i++) {
    if (i % 2 == 0) {
      drawCard(playerHand, playerAceIndex);
    } else {
      drawCard(opponentHand, opponentAceIndex);
    }
  }
}

function keyPressed() {
  if (checkCanDraw(playerHand) && key == "1") {
    stateText = "";
    drawCard(playerHand, playerAceIndex);
  }
  if (key == "2") {
    switch (checkCanPass(playerHand)) {
      case false:
        stateText = "You cannot pass your turn, you are below 16.";
        break;
      case true:
        stateText = "";
        opponentTurn = true;
        break;
    }
  }
}

function opponentsTurn() {
  if (!checkMultiplier) {
    switch (true) {
      case playerHand.length <= 3:
        riskMultiplier = floor(random(3) - 1);
        break;
      case playerHand.length > 3:
        riskMultiplier = floor(random(1, 3));
        break;
    }
    checkMultiplier = true;
  }
  if (checkCanDraw(opponentHand)) {
    if (
      checkTotal(opponentHand) < opponentRiskTolerance + riskMultiplier ||
      checkTotal(opponentHand) < 16
    ) {
      drawCard(opponentHand, opponentAceIndex);
    } else if (
      checkTotal(opponentHand) < opponentRiskTolerance + riskMultiplier + 9 &&
      opponentAceIndex.length > 0 &&
      opponentHand.length > 3
    ) {
      drawCard(opponentHand, opponentAceIndex);
    }
  }
  if (checkTotal(opponentHand) >= opponentRiskTolerance + riskMultiplier) {
    opponentFlip = true;
    switch (true) {
      case checkTotal(playerHand) > 21 && checkTotal(opponentHand) > 21:
        stateText = "You tied!";
        break;
      case checkTotal(playerHand) > checkTotal(opponentHand) &&
        checkTotal(playerHand) <= 21:
        stateText = "You win!";
        break;
      case checkTotal(opponentHand) > 21:
        stateText = "You win!";
        break;
      case checkTotal(playerHand) < checkTotal(opponentHand) &&
        checkTotal(opponentHand) <= 21:
        stateText = "You lost!";
        break;
      case checkTotal(playerHand) > 21:
        stateText = "You lost!";
        break;
      case checkTotal(playerHand) == checkTotal(opponentHand):
        stateText = "You tied!";
        break;
    }
  }
}

function aceValue(hand, aceHand) {
  if (checkTotal(hand) > 21) {
    for (let i = 0; i < aceHand.length; i++) {
      if (hand[aceHand[i]] == 11) {
        hand[aceHand[i]] = 10;
        if (checkTotal(hand) <= 21) {
          break;
        }
      }
    }
  }
  if (checkTotal(hand) > 21 && hand.length > 3) {
    for (let i = 0; i < aceHand.length; i++) {
      if (hand[aceHand[i]] == 10) {
        hand[aceHand[i]] = 1;
        if (checkTotal(hand) <= 21) {
          break;
        }
      }
    }
  }
}

function checkTotal(hand) {
  let total = 0;
  for (let i = 0; i < hand.length; i++) {
    total += hand[i];
  }
  return total;
}

function checkCanDraw(hand) {
  if (hand.length < 5) {
    return true;
  } else {
    return false;
  }
}

function checkCanPass(hand) {
  if (checkTotal(hand) < 16) {
    return false;
  } else {
    return true;
  }
}

function drawCard(hand, aceHand) {
  let index = int(random(deck.length - 1));
  let drawn = deck[index];
  hand.push(drawn);
  if (drawn == 11) {
    aceHand.push(hand.length - 1);
  }
  aceValue(hand, aceHand);
  deck.splice(index, 1);
}

function drawHand(hand, aceHand, flip) {
  const spacing = width / (hand.length + 1);
  for (let i = 0; i < hand.length; i++) {
    const x = (i + 1) * spacing;
    let y = 400;
    if (hand != playerHand) {
      y = 100;
    }
    const s = 20;
    push();
    translate(x, y);
    rectMode(CENTER);
    rect(0, 0, 75, 100);
    textSize(s);
      textAlign(CENTER, CENTER);
    let t = hand[i];
    if (aceHand.includes(i)) {
      t = "A";
    }
    if (flip) {
      text(t, 0, 0);
    }
    pop();
  }
}

function textState() {
  push();
  textSize(textS);
  textAlign(CENTER, CENTER);
  text(stateText, width / 2, height / 2);
  pop();
}
