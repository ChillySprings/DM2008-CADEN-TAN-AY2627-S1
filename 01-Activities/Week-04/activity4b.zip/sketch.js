let startTime = 0;
let duration = 30;
let die = [];
let size = 100;

function setup() {
  createCanvas(400, 400);
  die.push(new Dice(100, height / 2, size, 6));
  die.push(new Dice(300, height / 2, size, 7));
  frameRate(10);
}

function draw() {
  background(220);
  for (let i = 0; i < die.length; i++) {
    die[i].showDice();
    if (die[i].isDiceRolled == true) {
          die[i].rollDice();
    }
  }
}

function mousePressed() {
  for (let i = 0; i < die.length; i++) {
    die[i].isDiceRolled = true;
    startTime = frameCount;
  }
}

class Dice {
  constructor(x, y, size, endResult) {
    this.x = x;
    this.y = y;
    this.size = size;
    this.endResult = endResult;
    this.rotated = false;
    this.text = "1";
    this.textSize = 20;
    this.isDiceRolled = false;
    this.diceFaces = [
      1,
      2,
      3,
      4,
      5,
      6,
      7,
      8,
      9,
      10,
      11,
      12,
      13,
      14,
      15,
      16,
      17,
      18,
      19,
      20,
    ];
  }
  showDice() {
    push();
    translate(this.x, this.y);
    rectMode(CENTER);
    if (this.rotated) {
      rotate(QUARTER_PI);
    }
    square(0, 0, this.size);
    pop();
    textAlign(CENTER, CENTER);
    textSize(this.textSize);
    text(this.text, this.x, this.y);
  }
  rollDice() {
    let elapsed = frameCount - startTime;
    if (elapsed < duration) {
      this.text = str(this.diceFaces[int(random(0, 20))]);
      this.rotated = !this.rotated;
    } else {
      this.isDiceRolled = false;
      this.endDice();
    }
  }
  endDice() {
    this.text = str(this.endResult);
    this.rotated = false;
  }
}
