// DM2008 — Activity 4a [Guided]
// Bake a Cookie (30 min)
//
// A class is a blueprint — Cookie describes what every cookie has and can do.
// Your job is to complete the class, then add movement and a flavor randomizer.
//
// Suggested order:
// 1. Add the missing properties to the constructor (sz, x, y)
// 2. Fix show() so it uses this.flavor, this.x, this.y, this.sz
// 3. Implement move() and randomFlavor()
// 4. Wire them up in keyPressed() and mousePressed()
//
// Stretch: add a second cookie with different starting values.

let cookies = [];
let difficultyLevel = 0;

function setup() {
  createCanvas(400, 400);
  noStroke();
}

function draw() {
  background(230);
  if (frameCount % (120 - difficultyLevel * 10) == 0) {
    spawnCookie();
  }
  if (cookies != null) {
    for (let i = cookies.length - 1; i >= 0; i--) {
      if (cookies[i].health <= 0) {
        cookies.splice(i, 1);
      }
    }
  }
  if (cookies != null) {
    for (let i = 0; i < cookies.length; i++) {
      cookies[i].move();
    }
  }
  difficultyLevels();
}

function spawnCookie() {
  let s = 80;
  let x = random([0 - s, width + s]);
  let y = random([0 - s, height + s]);
  let flavor = int(random(0, difficultyLevel + 1));
  cookies.push(new Cookie(flavor, s, x, y));
  cookies[cookies.length - 1].chooseStats();
}

function difficultyLevels() {
  if (frameCount % 500 == 0 && difficultyLevel < 12) {
    difficultyLevel++;
  }
}

class Cookie {
  constructor(flavor, sz, x, y) {
    this.sz = sz;
    this.x = x;
    this.y = y;
    this.flavor = flavor;
    this.speed;
    this.health;
  }
  chooseStats() {
    switch (this.flavor) {
      case 0:
        // Basic
        fill("#f2cc97");
        this.speed = 0.02;
        this.health = 1;
        break;
      case 1:
        // Chocolate Chip
        fill("#b48055");
        this.speed = 0.05;
        this.health = 2;
        break;
      case 2:
        // Double Chocolate Chip
        fill("#603c1f");
        this.speed = 0.075;
        this.health = 3;
        break;
      default:
        // Dubai
        fill("#8fa979");
        this.speed = 0.1;
        this.health = 4;
        break;
    }
  }
  move() {
    let targetX = width / 2;
    let targetY = height / 2;
    this.x = lerp(this.x, targetX, this.speed);
    this.y = lerp(this.y, targetY, this.speed);
    ellipse(this.x, this.y, this.sz);
  }
  attackCookie() {
    if (dist(mouseX, mouseY, this.x, this.y) <= this.sz) {
      this.health--;
    }
  }
}
function mousePressed() {
  for (let i = 0; i < cookies.length; i++) {
    cookies[i].attackCookie();
  }
}
